function [v, pi] = policyIteration(model, maxit)

% initialize the value function
v = zeros(model.stateCount, 1);
pi = ones(model.stateCount, 1);
for i = 1:maxit
    % initialize the policy and the new value function
    pi_ = ones(model.stateCount, 1);
    v_ = zeros(model.stateCount, 1);
    pis = zeros(model.stateCount,1);
    
    for j = 1:maxit
        for s = 1:model.stateCount
            % COMPUTE THE VALUE FUNCTION AND POLICY
            % YOU CAN ALSO COMPUTE THE POLICY ONLY AT THE END
            tmpaweight = zeros(4,1);
            tmpa = zeros(4,1);
            for a = 1:4 
                Va = 0;
                for sp = 1:model.stateCount
                    tmpp = model.P(s,sp,a);
                    tmpr = model.R(s,a)+model.gamma*v(sp);
                    Va = Va + tmpp*tmpr;
                    if sp == model.stateCount
                        tmppias = sum(model.P(s,:,a));
                        tmpa(a) = Va;
                        tmpaweight(a) = tmppias*Va;
                    end
                end
            end
            v_(s) = sum(tmpaweight);       
        end

        if max(v_-v)<0.000000000001 %norm or max
            break
        else
            v = v_;
        end
    end
    

    
    % for policy 
    for s = 1:model.stateCount
        tmp = pi(s);
        tmpa = zeros(4,1);
        for a = 1:4
            Va = 0;
            for sp = 1:model.stateCount
                Va = Va + model.P(s,sp,a)*(model.R(s,a)+model.gamma*v(sp));
                if sp == model.stateCount
                    tmpa(a) = Va; 
                end
            end
        end
        choices = find(tmpa==max(tmpa));
        if length(choices) > 1
            choice = datasample(choices,1);
        elseif length(choices) == 0
            choice = 1;
        else
            choice = choices;
        end
%         disp(choices);
%         disp(length(choice));
        pi_(s) = choice;
        if pi_(s) == tmp
            pis(s) = 1;
        else
            pis(s) = 0;
        end
    end
    

    if length(pis)==sum(pis)
        break
    else
        pi = pi_;
    end

    
end
end
