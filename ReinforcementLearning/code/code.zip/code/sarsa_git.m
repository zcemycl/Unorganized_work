%sarsa github
function [v, pi, Cum_Rwd] = sarsa_git(model, maxit, maxeps)
% initialize the value function
Q = zeros(model.stateCount, 4);  
pi = ones(model.stateCount, 1);  
alpha = 1;
policy = ones(model.stateCount, 1);
Cum_Rwd = zeros(maxeps, 1);

for i = 1:maxeps,
    %every time we reset the episode, start at the given startState   
    %get Start State
    s = model.startState;
    %OR INITIALIZE ACTION ARBITRARILY
    a = 1;    
    % initialize the first action greedily as well
    %a = epsilon_greedy_policy(Q(s,:));
    Rwd = 0;

    for j = 1:maxit,    %FOR EACH STEP OF EPISODE
        p = 0;
        r = rand;

        for next_state = 1:model.stateCount,
            p = p + model.P(s, next_state, a);
            if r <= p,
                break;
            end
        end
              
        %TAKE ACTION, OBSERVE S' AND R
        s_ = next_state;
        
        %get R with given a
        Reward = model.R(s,a); 
        Rwd = Rwd + Reward;   %taking discounted cum rewards

        %CHOOSE A' FROM S' USING GREEDY POLICY
        a_ = epsilon_greedy_policy(Q(s_,:), j); 
        
        alpha = 1/j;
        % IMPLEMENT THE UPDATE RULE FOR Q HERE.
        Q(s,a) = Q(s,a) + alpha * [Reward + model.gamma * Q(s_, a_) - Q(s,a)];        
        s = s_;
        a = a_;
        
        [~, idx] = max(Q(s,:));
        policy(s) = idx;
        q = Q(:, idx);

         if s == model.goalState
            break;
         end             
    end   
    Cum_Rwd (i)  = Rwd/i;
end

pi = policy;
v = q;
end